# Design Brief for Claude Design — Warehouse & Multi-Shop Management System

You are designing the UI/UX for a real production app. Read this whole brief
before designing. Design serves the product here — this is working-tool UI,
not a marketing page. Every choice is judged by whether a hurried, non-technical
shop employee gets through their task faster and with fewer mistakes.

## 1. The product and its world

A trading business in Nouakchott, Mauritania imports goods (phones, AirPods,
accessories, clothing) into one central warehouse and distributes them to its
shops (currently two, more later). The app manages: incoming supplier orders,
warehouse stock, transfers to shops, sales at negotiated prices, customer
debts and later debt payments, expenses, receipts, and owner reports.

The cultural texture to draw from: a cash-based trading world of counters,
negotiated prices, handwritten ledgers, carbon-copy receipts, and personal
trust — a shopkeeper knows his customers and who owes what. The app replaces
the paper debt notebook. It should feel like a trustworthy modern ledger:
calm, precise, legible — never like a Silicon Valley SaaS dashboard.

## 2. Users and context of use

- **Shop employee** (primary): non-technical, using a mid-range Android phone,
  one-handed, standing at a counter with a customer waiting, possibly in
  bright sunlight. Speed and error-prevention over information density.
- **Warehouse employee**: receives shipments, transfers stock. Phone or tablet.
- **Owner**: checks the business on his phone during the day, deeper review on
  a laptop. The only user who sees money totals across shops.

No user has accounting knowledge. No user reads tooltips. If a screen needs
explaining, it's wrong.

## 3. Hard product constraints (non-negotiable)

1. **Bilingual French / Arabic with full RTL.** Design RTL-first, not as a
   mirrored afterthought: every screen must be shown in Arabic RTL as the
   primary comp, French LTR as the variant. Use direction-neutral layouts and
   logical alignment (start/end, never hardcoded left/right).
2. **Typography must carry both scripts as equals.** Choose a typeface pairing
   where Arabic is a first-class citizen, not a fallback — e.g. IBM Plex Sans
   Arabic + IBM Plex Sans, or Cairo/Tajawal/Noto Sans Arabic paired with a
   compatible Latin face. Arabic needs slightly larger size and looser line
   height than Latin at the same optical weight — set two coordinated type
   scales. Numerals: Western digits (0-9) everywhere, including in Arabic
   locale — these are money figures that must be unambiguous.
3. **Money is the protagonist.** Amounts are integers in MRU (no decimals).
   Design a money display style (tabular numerals, consistent size hierarchy)
   and use it everywhere. The system's most important distinction — **sales
   value vs money actually collected vs outstanding debt** — must be visually
   unmistakable, on the dashboard and on every sale. Never let a design
   imply that a debt sale is money in the drawer.
4. **Status is text + color, never color alone** (also an explicit client
   requirement): Paid / Partially Paid / Unpaid / Cancelled / Low Stock /
   Out of Stock / Archived etc. as labeled badges.
5. **Receipts are a separate design register**: pure white background, black
   text, no color, no graphics, optimized for browser printing and 80mm
   thermal printers. Sale receipt and payment receipt. Design these as their
   own print layouts, not a styled app screen.
6. **Roles see different apps.** Shop employee: only their shop (sell, stock,
   customers, payments, expenses). Warehouse employee: stock, receiving,
   transfers — no finances. Owner: everything. Navigation must be role-shaped,
   bottom nav on mobile with max 5 items per role.

## 4. Screens to design (in priority order)

1. **The sale flow** — the hero of the product; spend your best thinking here.
   Search/pick products → cart with per-line editable negotiated price →
   payment step (amount paid now, remaining auto-calculated, customer required
   the moment remaining > 0, inline customer creation) → confirmation with
   Print Receipt. Must be completable in under ~20 seconds for a simple sale,
   one-handed. Show empty cart, insufficient-stock error, and the
   "customer required because debt exists" moment.
2. **Shop employee home** — today's numbers for their shop + the big actions:
   Sell, Register Payment, Add Expense.
3. **Owner dashboard** — today's sales value / cash collected / new debt
   (three distinct figures), total outstanding debt, low stock, per-shop
   summary cards. Numbers first; no decorative charts.
4. **Customer account page** — total bought / paid / outstanding, list of
   unpaid sales with per-sale remaining, payment history, Register Payment
   as the primary action. This screen replaces the paper debt notebook —
   it must feel instantly trustworthy.
5. **Register payment flow** — amount entry against outstanding debt,
   oldest-first allocation shown simply ("this pays off SAL-000015 and part
   of SAL-000021"), confirmation with debt-before → debt-after.
6. **Warehouse stock list & shop stock list** — searchable, category filter,
   quantity prominent, Low/Out-of-stock badges, image thumbnails where
   available.
7. **Transfer flow** — pick products with available quantities visible,
   destination shop, confirm summary.
8. **Receive order flow** — order items with ordered/received/remaining,
   entering today's received quantities.
9. **Receipts** (print register, per §3.5).
10. **Login** — username + numeric PIN, large touch keypad-friendly.
11. **System states**: empty states (first-run, no products, no debts —
    each an invitation to act, per-role), destructive confirmations
    (cancel sale, reverse payment — always with a reason field), and
    error messages in the interface's voice (plain, specific, no apology).

## 5. Quality floor (apply everywhere, verify before delivering)

- Contrast ≥ 4.5:1 for body text (≥3:1 large text) — check it, especially
  muted text and text-on-color; assume sunlight readability matters.
- Touch targets ≥ 44×44px with ≥8px spacing; primary action reachable by
  thumb (bottom-anchored on mobile forms).
- Base body 16px+, line-height ≥1.5 (more for Arabic); no body text under 14px.
- Visible field labels always — never placeholder-only; errors adjacent to
  their field; optional fields explicitly marked (most fields here are
  optional by design — name+category is enough for a product).
- Real SVG icons (one consistent set, e.g. Lucide) — never emoji; icons
  paired with labels in navigation.
- Motion: 150–300ms, ease-out, purposeful only (state feedback, sheet
  transitions); reduced-motion alternative; nothing decorative.
- Loading and success feedback on every mutation ("Sale completed —
  remaining debt: 6,000 MRU" pattern); no instant unexplained state changes.
- Mobile-first 360px up to desktop; no horizontal scroll; tables collapse
  to cards on mobile.

## 6. Aesthetic direction — where your judgment comes in

Avoid the three AI-default looks (warm-cream + serif + terracotta;
near-black + acid accent; broadsheet hairlines) and avoid generic
admin-template blue-gray. Ground the palette in this product's world and
climate instead, and commit to it. Trust, heat, cash, ledger — your reading.

Spend your boldness in exactly one place: choose **one signature element**
this app is remembered by — candidates: the money/debt display treatment,
the paid-vs-remaining visualization on a sale, the ledger-like movement
history, the receipt aesthetic echoed subtly in-app — and keep everything
else quiet and disciplined. Justify the choice in one sentence.

Deliver design tokens as CSS custom properties (colors incl. semantic
status colors, both type scales, spacing, radius, z-index scale) —
the build is React + Tailwind, and tokens will be consumed directly.

## 7. Anti-goals

Do not design: charts-heavy analytics, settings sprawl, multi-currency,
notifications, e-commerce/product-catalog aesthetics, onboarding tours,
dark mode (v1 is light-only — sunlight legibility wins), or any feature
not listed in §4. Simplicity is a client requirement, not a style choice.

## Deliverables

1. Design tokens (CSS variables) + type scales for both scripts.
2. Component inventory (buttons, inputs, MoneyInput, status badges, list
   rows/cards, bottom nav, sheets/dialogs, search field, quantity stepper).
3. Hi-fi screens for §4 items 1–5 in mobile Arabic-RTL + mobile French-LTR,
   plus owner dashboard in desktop.
4. Print receipt layouts (sale + payment).
5. One paragraph stating the signature element and the reasoning.
